using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class SampleScript : MonoBehaviour
{
    public abstract void Use();
}
