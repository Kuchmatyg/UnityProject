Текстуры и материалы взяты из ассета Standard Assets (for Unity 2018.4)

https://assetstore.unity.com/packages/essentials/asset-packs/standard-assets-for-unity-2018-4-32351

Сам ассет является устаревшим и не поддерживается, но многие материалы из него до сих пор полезны.